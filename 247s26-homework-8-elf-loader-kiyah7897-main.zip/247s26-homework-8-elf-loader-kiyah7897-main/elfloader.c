#include <stdio.h>
#include "elfheader.h"

int main(int argc, char** argv) {
    // Remove this code and enter your own
    printf("The hobbits are going to Isengard!\n");
    return 0;
}
